#!/usr/bin/env python3
"""
Point d'entrée principal pour l'exécution directe du package.
"""

from git_commit_simplifier.cli import main

if __name__ == "__main__":
    main()
