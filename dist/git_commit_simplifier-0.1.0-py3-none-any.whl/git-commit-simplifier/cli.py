#!/usr/bin/env python3
"""Command-line interface for git-commit-simplifier."""

import os
import re
import time
from typing import Dict, List, Optional, Tuple, Set

import click
from colorama import Fore, Style, init
from git import Repo, GitCommandError, InvalidGitRepositoryError
from git.diff import Diff

from .config import get_config_value, init_config, set_config_value
from .conventional import generate_conventional_commit_message
from .interactive import select_files_interactively, stage_selected_files

init()  # Initialize colorama

def get_file_category(file_path: str) -> str:
    """Determine the category of a file based on its path.
    
    Args:
        file_path: Path to the file
        
    Returns:
        Category of the file
    """
    # Get custom categories from config
    categories = get_config_value("categories")
    
    for category, patterns in categories.items():
        for pattern in patterns:
            if re.search(pattern, file_path, re.IGNORECASE):
                return category
    
    # Determine by extension if no specific category matched
    ext = os.path.splitext(file_path)[1].lower()
    if ext in ['.py', '.pyx', '.pyi']:
        return 'python'
    elif ext in ['.js', '.ts']:
        return 'javascript'
    elif ext in ['.java', '.kt', '.scala']:
        return 'java'
    elif ext in ['.c', '.cpp', '.h', '.hpp']:
        return 'c/c++'
    elif ext in ['.go']:
        return 'go'
    elif ext in ['.rb']:
        return 'ruby'
    elif ext in ['.php']:
        return 'php'
    
    return 'other'

def get_change_type(diff_content: str) -> str:
    """Determine the type of change based on diff content.
    
    Args:
        diff_content: Content of the diff
        
    Returns:
        Type of change
    """
    # Get custom change types from config
    change_types = get_config_value("change_types")
    
    for change_type, patterns in change_types.items():
        for pattern in patterns:
            if re.search(pattern, diff_content, re.IGNORECASE):
                return change_type
    
    return 'update'  # Default change type

def analyze_diff_content(diff: Diff) -> Tuple[str, List[str]]:
    """Analyze the content of a diff to determine the nature of changes.
    
    Args:
        diff: Git diff object
        
    Returns:
        Tuple of (change_type, details)
    """
    try:
        diff_content = diff.diff.decode('utf-8')
    except (UnicodeDecodeError, AttributeError):
        return 'update', []
    
    details = []
    
    # Count added and removed lines
    added_lines = len([line for line in diff_content.split('\n') if line.startswith('+')])
    removed_lines = len([line for line in diff_content.split('\n') if line.startswith('-')])
    
    # Check for specific patterns in the diff
    if 'import' in diff_content:
        details.append('dependency changes')
    
    if re.search(r'class\s+\w+', diff_content):
        details.append('class definition changes')
    
    if re.search(r'def\s+\w+', diff_content):
        details.append('function definition changes')
    
    if re.search(r'^\+\s*#', diff_content, re.MULTILINE) or re.search(r'^\+\s*"""', diff_content, re.MULTILINE):
        details.append('documentation updates')
    
    # Check for breaking changes
    if re.search(r'BREAKING CHANGE', diff_content, re.IGNORECASE) or \
       re.search(r'BREAKING-CHANGE', diff_content, re.IGNORECASE) or \
       re.search(r'BREAKING_CHANGE', diff_content, re.IGNORECASE):
        details.append('breaking')
    
    # Determine change type
    change_type = get_change_type(diff_content)
    
    return change_type, details

def analyze_changes(repo_path: str) -> Optional[Dict[str, List[Dict]]]:
    """Analyze Git changes and generate commit message suggestions.
    
    Args:
        repo_path: Path to the Git repository
        
    Returns:
        Dictionary containing detailed information about changes
    """
    try:
        repo = Repo(repo_path)
    except InvalidGitRepositoryError:
        click.echo(f"{Fore.RED}Error: The directory '{repo_path}' is not a valid Git repository.{Style.RESET_ALL}")
        click.echo(f"{Fore.YELLOW}Tip: Make sure you're in the correct directory or initialize a Git repository with 'git init'.{Style.RESET_ALL}")
        return None
    except Exception as e:
        click.echo(f"{Fore.RED}Error accessing Git repository: {str(e)}{Style.RESET_ALL}")
        return None
    
    try:
        # Performance optimization: For large repositories, limit the diff to a reasonable size
        max_diff_files = get_config_value("max_diff_files", 500)
        
        # Check for staged changes first
        start_time = time.time()
        staged_changes = list(repo.index.diff('HEAD'))
        
        # If it's taking too long (more than 2 seconds), show a progress message
        if time.time() - start_time > 2:
            click.echo(f"{Fore.YELLOW}Analyzing staged changes... This might take a moment for large repositories.{Style.RESET_ALL}")
        
        if len(staged_changes) > max_diff_files:
            click.echo(f"{Fore.YELLOW}Warning: Large number of staged changes detected. Limiting analysis to {max_diff_files} files.{Style.RESET_ALL}")
            staged_changes = staged_changes[:max_diff_files]
        
        # Get untracked files
        start_time = time.time()
        untracked_files = repo.untracked_files
        
        # If it's taking too long, show a progress message
        if time.time() - start_time > 2:
            click.echo(f"{Fore.YELLOW}Analyzing untracked files... This might take a moment for large repositories.{Style.RESET_ALL}")
        
        if len(untracked_files) > max_diff_files:
            click.echo(f"{Fore.YELLOW}Warning: Large number of untracked files detected. Limiting analysis to {max_diff_files} files.{Style.RESET_ALL}")
            untracked_files = untracked_files[:max_diff_files]
        
        # If no staged changes, check for unstaged changes
        if not staged_changes and not untracked_files:
            start_time = time.time()
            unstaged_changes = list(repo.index.diff(None))
            
            # If it's taking too long, show a progress message
            if time.time() - start_time > 2:
                click.echo(f"{Fore.YELLOW}Analyzing unstaged changes... This might take a moment for large repositories.{Style.RESET_ALL}")
            
            if len(unstaged_changes) > max_diff_files:
                click.echo(f"{Fore.YELLOW}Warning: Large number of unstaged changes detected. Limiting analysis to {max_diff_files} files.{Style.RESET_ALL}")
                unstaged_changes = unstaged_changes[:max_diff_files]
            
            if not unstaged_changes:
                click.echo(f"{Fore.YELLOW}No changes detected in the repository.{Style.RESET_ALL}")
                return None
            
            # Check if interactive mode is enabled
            interactive = get_config_value("interactive", False)
            if interactive:
                try:
                    selected_files = select_files_interactively(repo, unstaged_changes, untracked_files)
                    stage_selected_files(repo, selected_files)
                    # Refresh the staged changes
                    staged_changes = list(repo.index.diff('HEAD'))
                    untracked_files = [f for f in repo.untracked_files if f not in selected_files]
                except Exception as e:
                    click.echo(f"{Fore.RED}Error in interactive mode: {str(e)}{Style.RESET_ALL}")
                    click.echo(f"{Fore.YELLOW}Falling back to command-line prompt.{Style.RESET_ALL}")
                    interactive = False
            
            if not interactive:
                # Check if auto-stage is enabled
                auto_stage = get_config_value("auto_stage", True)
                if auto_stage and click.confirm(f"{Fore.YELLOW}No staged changes found. Would you like to stage all changes?{Style.RESET_ALL}"):
                    # Use a progress bar for large repositories
                    with click.progressbar(
                        unstaged_changes,
                        label=f"{Fore.GREEN}Staging files{Style.RESET_ALL}",
                        item_show_func=lambda item: item.a_path if item else ""
                    ) as bar:
                        for item in bar:
                            try:
                                repo.git.add(item.a_path)
                            except Exception as e:
                                click.echo(f"\n{Fore.RED}Error staging {item.a_path}: {str(e)}{Style.RESET_ALL}")
                    
                    # Stage untracked files as well
                    with click.progressbar(
                        untracked_files,
                        label=f"{Fore.GREEN}Staging untracked files{Style.RESET_ALL}",
                        item_show_func=lambda item: item
                    ) as bar:
                        for file in bar:
                            try:
                                repo.git.add(file)
                            except Exception as e:
                                click.echo(f"\n{Fore.RED}Error staging {file}: {str(e)}{Style.RESET_ALL}")
                    
                    click.echo(f"{Fore.GREEN}All changes have been staged.{Style.RESET_ALL}")
                    # Refresh the staged changes
                    staged_changes = list(repo.index.diff('HEAD'))
                    untracked_files = []
                else:
                    click.echo(f"{Fore.YELLOW}Please stage the changes you want to commit and try again.{Style.RESET_ALL}")
                    click.echo(f"{Fore.YELLOW}You can stage files using 'git add <file>' or 'git add -A' to stage all changes.{Style.RESET_ALL}")
                    return None
        
        # Analyze changes
        changes = {
            'added': [],
            'modified': [],
            'deleted': [],
            'renamed': [],
            'categories': {}
        }
        
        # Process staged changes
        with click.progressbar(
            staged_changes,
            label=f"{Fore.CYAN}Analyzing staged changes{Style.RESET_ALL}",
            item_show_func=lambda item: item.a_path if item else "",
            length=len(staged_changes)
        ) as bar:
            for item in bar:
                file_info = {
                    'path': item.a_path,
                    'category': get_file_category(item.a_path),
                }
                
                if item.new_file:
                    file_info['change_type'], file_info['details'] = 'feature', ['new file']
                    changes['added'].append(file_info)
                elif item.deleted_file:
                    file_info['change_type'], file_info['details'] = 'chore', ['removed file']
                    changes['deleted'].append(file_info)
                elif item.renamed:
                    file_info['path'] = f"{item.rename_from} → {item.rename_to}"
                    file_info['change_type'], file_info['details'] = 'refactor', ['renamed file']
                    changes['renamed'].append(file_info)
                else:
                    file_info['change_type'], file_info['details'] = analyze_diff_content(item)
                    changes['modified'].append(file_info)
                
                # Group by category
                category = file_info['category']
                if category not in changes['categories']:
                    changes['categories'][category] = []
                changes['categories'][category].append(file_info)
        
        # Process untracked files
        if untracked_files:
            with click.progressbar(
                untracked_files,
                label=f"{Fore.CYAN}Analyzing untracked files{Style.RESET_ALL}",
                item_show_func=lambda item: item,
                length=len(untracked_files)
            ) as bar:
                for file_path in bar:
                    file_info = {
                        'path': file_path,
                        'category': get_file_category(file_path),
                        'change_type': 'feature',
                        'details': ['new file']
                    }
                    changes['added'].append(file_info)
                    
                    # Group by category
                    category = file_info['category']
                    if category not in changes['categories']:
                        changes['categories'][category] = []
                    changes['categories'][category].append(file_info)
        
        return changes
    
    except GitCommandError as e:
        click.echo(f"{Fore.RED}Git command error: {str(e)}{Style.RESET_ALL}")
        cmd = e.command[0] if isinstance(e.command, list) and e.command else str(e.command)
        click.echo(f"{Fore.YELLOW}Failed command: git {cmd}{Style.RESET_ALL}")
        
        # Provide helpful tips based on the error
        if "not a git repository" in str(e).lower():
            click.echo(f"{Fore.YELLOW}Tip: Make sure you're in a Git repository. You can initialize one with 'git init'.{Style.RESET_ALL}")
        elif "fatal: bad revision 'HEAD'" in str(e):
            click.echo(f"{Fore.YELLOW}Tip: It seems this repository doesn't have any commits yet. Make an initial commit first.{Style.RESET_ALL}")
        elif "Permission denied" in str(e):
            click.echo(f"{Fore.YELLOW}Tip: You don't have permission to access this repository. Check your file permissions.{Style.RESET_ALL}")
        
        return None
    except Exception as e:
        click.echo(f"{Fore.RED}Error analyzing changes: {str(e)}{Style.RESET_ALL}")
        return None

def generate_commit_message(changes: Dict[str, List[Dict]]) -> str:
    """Generate a commit message based on the changes.
    
    Args:
        changes: Dictionary containing detailed information about changes
        
    Returns:
        Formatted commit message
    """
    # Check the commit style from config
    commit_style = get_config_value("commit_style", "detailed")
    
    if commit_style == "conventional":
        return generate_conventional_commit_message(changes)
    
    # For detailed or simple style, continue with the original implementation
    # Determine the primary change type
    change_types = {}
    for change_list in [changes.get('added', []), changes.get('modified', []), 
                        changes.get('deleted', []), changes.get('renamed', [])]:
        for item in change_list:
            change_type = item.get('change_type', 'update')
            change_types[change_type] = change_types.get(change_type, 0) + 1
    
    primary_change_type = max(change_types.items(), key=lambda x: x[1])[0] if change_types else 'update'
    
    # Check if emoji should be used
    use_emoji = get_config_value("emoji", False)
    emoji_map = get_config_value("emoji_map", {})
    
    # Generate the commit message
    message_parts = []
    
    # Generate the subject line
    if primary_change_type == 'feature':
        subject = "Add "
    elif primary_change_type == 'fix':
        subject = "Fix "
    elif primary_change_type == 'refactor':
        subject = "Refactor "
    elif primary_change_type == 'docs':
        subject = "Update documentation for "
    elif primary_change_type == 'test':
        subject = "Add tests for "
    elif primary_change_type == 'style':
        subject = "Improve styling of "
    elif primary_change_type == 'performance':
        subject = "Optimize "
    elif primary_change_type == 'chore':
        subject = "Update "
    else:
        subject = "Update "
    
    # Add emoji if enabled
    if use_emoji and primary_change_type in emoji_map:
        subject = f"{emoji_map[primary_change_type]} {subject}"
    
    # Add the main category or files to the subject
    if len(changes['categories']) == 1:
        category = next(iter(changes['categories']))
        subject += f"{category} "
    elif len(changes.get('added', [])) + len(changes.get('modified', [])) + len(changes.get('deleted', [])) + len(changes.get('renamed', [])) <= 3:
        # If few files changed, list them in the subject
        files = []
        for change_list in [changes.get('added', []), changes.get('modified', []), 
                            changes.get('deleted', []), changes.get('renamed', [])]:
            for item in change_list:
                files.append(os.path.basename(item['path'].split(' → ')[-1]))
        subject += ", ".join(files)
    else:
        # Otherwise, use a general description
        subject += "multiple files"
    
    # Ensure subject line is not too long
    max_subject_length = get_config_value("max_subject_length", 72)
    if len(subject) > max_subject_length:
        subject = subject[:max_subject_length-3] + "..."
    
    message_parts.append(subject)
    
    # For simple style, just return the subject line
    if commit_style == "simple":
        return subject
    
    # For detailed style, add more information
    message_parts.append("")  # Empty line after subject
    
    # Add detailed description
    for category, items in changes['categories'].items():
        if items:
            message_parts.append(f"## {category.capitalize()}")
            for item in items:
                path = item['path']
                change_type = item['change_type']
                details = item.get('details', [])
                
                if change_type == 'feature':
                    prefix = "Add"
                elif change_type == 'fix':
                    prefix = "Fix"
                elif change_type == 'refactor':
                    prefix = "Refactor"
                elif change_type == 'docs':
                    prefix = "Document"
                elif change_type == 'test':
                    prefix = "Test"
                elif change_type == 'style':
                    prefix = "Style"
                elif change_type == 'performance':
                    prefix = "Optimize"
                elif change_type == 'chore':
                    prefix = "Update"
                else:
                    prefix = "Update"
                
                # Add emoji if enabled
                if use_emoji and change_type in emoji_map:
                    prefix = f"{emoji_map[change_type]} {prefix}"
                
                detail_text = f" ({', '.join(details)})" if details else ""
                message_parts.append(f"- {prefix} {path}{detail_text}")
            
            message_parts.append("")  # Empty line after each category
    
    return "\n".join(message_parts).strip()

def display_changes(changes: Dict[str, List[Dict]]) -> None:
    """Display the changes in a user-friendly format.
    
    Args:
        changes: Dictionary containing detailed information about changes
    """
    click.echo(f"\n{Fore.CYAN}Changes detected:{Style.RESET_ALL}")
    
    if changes.get('added'):
        click.echo(f"\n{Fore.GREEN}Added files:{Style.RESET_ALL}")
        for item in changes['added']:
            click.echo(f"  {Fore.GREEN}+{Style.RESET_ALL} {item['path']} ({item['category']})")
    
    if changes.get('modified'):
        click.echo(f"\n{Fore.YELLOW}Modified files:{Style.RESET_ALL}")
        for item in changes['modified']:
            details = f" - {', '.join(item['details'])}" if item.get('details') else ""
            click.echo(f"  {Fore.YELLOW}~{Style.RESET_ALL} {item['path']} ({item['category']}){details}")
    
    if changes.get('deleted'):
        click.echo(f"\n{Fore.RED}Deleted files:{Style.RESET_ALL}")
        for item in changes['deleted']:
            click.echo(f"  {Fore.RED}-{Style.RESET_ALL} {item['path']} ({item['category']})")
    
    if changes.get('renamed'):
        click.echo(f"\n{Fore.BLUE}Renamed files:{Style.RESET_ALL}")
        for item in changes['renamed']:
            click.echo(f"  {Fore.BLUE}→{Style.RESET_ALL} {item['path']} ({item['category']})")
    
    click.echo("")

@click.group(invoke_without_command=True)
@click.pass_context
@click.option('--path', default='.', help='Path to the Git repository')
@click.option('--preview/--no-preview', default=True, help='Preview changes before committing')
@click.option('--edit/--no-edit', default=True, help='Edit the commit message before committing')
@click.option('--push/--no-push', default=None, help='Push changes after committing')
@click.option('--style', type=click.Choice(['detailed', 'conventional', 'simple']), 
              help='Commit message style')
@click.option('--emoji/--no-emoji', default=None, help='Use emoji in commit messages')
@click.option('--interactive/--no-interactive', default=None, help='Use interactive mode for staging')
@click.version_option()
def main(ctx, path, preview, edit, push, style, emoji, interactive):
    """Generate commit message suggestions based on Git changes.
    
    If no command is specified, the default behavior is to analyze changes and suggest a commit message.
    """
    # Initialize config if this is the first run
    init_config()
    
    # Update config with command-line options if provided
    if style is not None:
        set_config_value("commit_style", style)
    
    if emoji is not None:
        set_config_value("emoji", emoji)
    
    if push is not None:
        set_config_value("auto_push", push)
    
    if interactive is not None:
        set_config_value("interactive", interactive)
    
    # If a subcommand was invoked, let it handle the rest
    if ctx.invoked_subcommand is not None:
        return
    
    # Default behavior: analyze changes and suggest commit message
    try:
        changes = analyze_changes(path)
        if not changes:
            return
        
        if preview:
            display_changes(changes)
        
        commit_message = generate_commit_message(changes)
        click.echo(f"\n{Fore.GREEN}Suggested commit message:{Style.RESET_ALL}")
        click.echo(f"{Fore.CYAN}{commit_message}{Style.RESET_ALL}")
        
        if edit:
            try:
                edited = click.edit(commit_message)
                if edited:
                    commit_message = edited.strip()
                    click.echo(f"\n{Fore.GREEN}Edited commit message:{Style.RESET_ALL}")
                    click.echo(f"{Fore.CYAN}{commit_message}{Style.RESET_ALL}")
            except Exception as e:
                click.echo(f"{Fore.RED}Error opening editor: {str(e)}{Style.RESET_ALL}")
                click.echo(f"{Fore.YELLOW}Using the suggested commit message instead.{Style.RESET_ALL}")
        
        if click.confirm('\nDo you want to commit with this message?'):
            try:
                repo = Repo(path)
                commit = repo.index.commit(commit_message)
                click.echo(f"{Fore.GREEN}Changes committed successfully!{Style.RESET_ALL}")
                click.echo(f"{Fore.GREEN}Commit hash: {commit.hexsha[:8]}{Style.RESET_ALL}")
                
                # Check if auto-push is enabled
                auto_push = get_config_value("auto_push", False) if push is None else push
                if auto_push and click.confirm('Do you want to push the changes?'):
                    try:
                        origin = repo.remote(name='origin')
                        current_branch = repo.active_branch.name
                        push_info = origin.push(current_branch)
                        
                        # Check if push was successful
                        if push_info and all(info.flags & info.UP_TO_DATE or info.flags & info.FAST_FORWARD for info in push_info):
                            click.echo(f"{Fore.GREEN}Changes pushed to {origin.name}/{current_branch}!{Style.RESET_ALL}")
                        else:
                            click.echo(f"{Fore.YELLOW}Push completed, but with warnings. Check 'git status' for details.{Style.RESET_ALL}")
                    except GitCommandError as e:
                        click.echo(f"{Fore.RED}Error pushing changes: {str(e)}{Style.RESET_ALL}")
                        
                        # Provide helpful suggestions based on common errors
                        if "Permission denied" in str(e):
                            click.echo(f"{Fore.YELLOW}Tip: You might need to set up authentication for the remote repository.{Style.RESET_ALL}")
                        elif "non-fast-forward" in str(e):
                            click.echo(f"{Fore.YELLOW}Tip: Remote has changes you don't have locally. Try 'git pull' first, then push again.{Style.RESET_ALL}")
                        elif "remote: Repository not found" in str(e):
                            click.echo(f"{Fore.YELLOW}Tip: The remote repository doesn't exist or you don't have access to it.{Style.RESET_ALL}")
            except GitCommandError as e:
                click.echo(f"{Fore.RED}Error committing changes: {str(e)}{Style.RESET_ALL}")
            except Exception as e:
                click.echo(f"{Fore.RED}Error: {str(e)}{Style.RESET_ALL}")
    except KeyboardInterrupt:
        click.echo(f"\n{Fore.YELLOW}Operation cancelled by user.{Style.RESET_ALL}")
    except Exception as e:
        click.echo(f"{Fore.RED}Error: {str(e)}{Style.RESET_ALL}")


@main.command()
@click.option('--style', type=click.Choice(['detailed', 'conventional', 'simple']), 
              default='detailed', help='Commit message style')
@click.option('--emoji/--no-emoji', default=False, help='Use emoji in commit messages')
@click.option('--auto-push/--no-auto-push', default=False, help='Automatically push after committing')
@click.option('--auto-stage/--no-auto-stage', default=True, help='Automatically stage changes')
@click.option('--interactive/--no-interactive', default=False, help='Use interactive mode for staging')
@click.option('--max-diff-files', default=500, help='Maximum number of files to analyze in large repositories')
def config(style, emoji, auto_push, auto_stage, interactive, max_diff_files):
    """Configure git-commit-simplifier settings."""
    # Update config with provided options
    set_config_value("commit_style", style)
    set_config_value("emoji", emoji)
    set_config_value("auto_push", auto_push)
    set_config_value("auto_stage", auto_stage)
    set_config_value("interactive", interactive)
    set_config_value("max_diff_files", max_diff_files)
    
    click.echo(f"{Fore.GREEN}Configuration updated successfully!{Style.RESET_ALL}")
    click.echo(f"\n{Fore.CYAN}Current configuration:{Style.RESET_ALL}")
    click.echo(f"  Commit style: {style}")
    click.echo(f"  Use emoji: {emoji}")
    click.echo(f"  Auto-push: {auto_push}")
    click.echo(f"  Auto-stage: {auto_stage}")
    click.echo(f"  Interactive mode: {interactive}")
    click.echo(f"  Max diff files: {max_diff_files}")


if __name__ == '__main__':
    main()
