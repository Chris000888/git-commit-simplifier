"""Configuration module for git-commit-simplifier."""

import os
import json
from typing import Dict, Any, Optional

# Default configuration
DEFAULT_CONFIG = {
    "commit_style": "detailed",  # Options: "detailed", "conventional", "simple"
    "emoji": False,              # Whether to use emoji in commit messages
    "max_subject_length": 72,    # Maximum length of the subject line
    "categories": {              # Custom file categories
        "documentation": [r"\.md$", r"\.rst$", r"docs/", r"README", r"CHANGELOG", r"LICENSE"],
        "configuration": [r"\.toml$", r"\.yaml$", r"\.yml$", r"\.ini$", r"\.cfg$", r"\.conf$", r"\.json$"],
        "test": [r"test_.*\.py$", r".*_test\.py$", r"tests/", r"pytest", r"unittest"],
        "style": [r"\.css$", r"\.scss$", r"\.less$", r"\.sass$"],
        "ui": [r"\.html$", r"\.jsx$", r"\.tsx$", r"templates/"],
        "database": [r"\.sql$", r"migrations/", r"models/", r"schema"],
        "build": [r"setup\.py$", r"Makefile$", r"requirements", r"Dockerfile", r"\.github/"]
    },
    "change_types": {            # Custom change type patterns
        "fix": [r"fix", r"bug", r"issue", r"error", r"crash", r"resolve", r"closes #"],
        "feature": [r"add", r"new", r"feature", r"implement", r"support for"],
        "refactor": [r"refactor", r"clean", r"reorganize", r"restructure", r"rewrite"],
        "performance": [r"optimiz", r"performance", r"speed", r"memory", r"efficien"],
        "test": [r"test", r"assert", r"mock", r"stub"],
        "docs": [r"doc", r"comment", r"readme", r"changelog"],
        "style": [r"style", r"format", r"indent", r"lint"],
        "chore": [r"version", r"dependency", r"package", r"merge", r"config"]
    },
    "emoji_map": {               # Emoji for different change types
        "fix": "🐛",
        "feature": "✨",
        "refactor": "♻️",
        "performance": "⚡",
        "test": "✅",
        "docs": "📝",
        "style": "💄",
        "chore": "🔧"
    },
    "conventional_types": [      # Valid types for conventional commits
        "feat", "fix", "docs", "style", "refactor", "perf", "test", "build", "ci", "chore", "revert"
    ],
    "auto_push": False,          # Whether to automatically push after committing
    "auto_stage": True,          # Whether to automatically stage changes
    "interactive": False,        # Whether to use interactive mode
    "max_diff_files": 500        # Maximum number of files to analyze in large repositories
}


def get_config_path() -> str:
    """Get the path to the configuration file.
    
    Returns:
        Path to the configuration file
    """
    # Check for config in the current directory first
    if os.path.exists('.git-commit-simplifier.json'):
        return '.git-commit-simplifier.json'
    
    # Then check in the user's home directory
    home_config = os.path.expanduser('~/.git-commit-simplifier.json')
    if os.path.exists(home_config):
        return home_config
    
    # Finally check in XDG_CONFIG_HOME if available
    xdg_config_home = os.environ.get('XDG_CONFIG_HOME')
    if xdg_config_home:
        xdg_config = os.path.join(xdg_config_home, 'git-commit-simplifier.json')
        if os.path.exists(xdg_config):
            return xdg_config
    
    # Return the default path in the user's home directory
    return home_config


def load_config() -> Dict[str, Any]:
    """Load the configuration from the configuration file.
    
    Returns:
        Configuration dictionary
    """
    config_path = get_config_path()
    
    # If the config file exists, load it
    if os.path.exists(config_path):
        try:
            with open(config_path, 'r') as f:
                user_config = json.load(f)
            
            # Merge with default config
            config = DEFAULT_CONFIG.copy()
            
            # Deep merge for nested dictionaries
            for key, value in user_config.items():
                if isinstance(value, dict) and key in config and isinstance(config[key], dict):
                    # For dictionaries, merge instead of replace
                    config[key].update(value)
                else:
                    # For other values, replace
                    config[key] = value
                    
            return config
        except json.JSONDecodeError:
            print(f"Error: Config file {config_path} is not valid JSON. Using default configuration.")
            return DEFAULT_CONFIG
        except Exception as e:
            print(f"Error loading config file: {str(e)}")
            return DEFAULT_CONFIG
    
    return DEFAULT_CONFIG


def save_config(config: Dict[str, Any]) -> bool:
    """Save the configuration to the configuration file.
    
    Args:
        config: Configuration dictionary
        
    Returns:
        True if the configuration was saved successfully, False otherwise
    """
    config_path = get_config_path()
    
    try:
        # Create directory if it doesn't exist
        config_dir = os.path.dirname(os.path.abspath(config_path))
        if config_dir and not os.path.exists(config_dir):
            os.makedirs(config_dir, exist_ok=True)
        
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
        return True
    except Exception as e:
        print(f"Error saving config file: {str(e)}")
        return False


def init_config() -> Dict[str, Any]:
    """Initialize the configuration file with default values.
    
    Returns:
        Configuration dictionary
    """
    config_path = get_config_path()
    
    # If the config file doesn't exist, create it
    if not os.path.exists(config_path):
        save_config(DEFAULT_CONFIG)
    
    return load_config()


def get_config_value(key: str, default: Optional[Any] = None) -> Any:
    """Get a value from the configuration.
    
    Args:
        key: Configuration key
        default: Default value if the key doesn't exist
        
    Returns:
        Configuration value
    """
    config = load_config()
    return config.get(key, default)


def set_config_value(key: str, value: Any) -> bool:
    """Set a value in the configuration.
    
    Args:
        key: Configuration key
        value: Configuration value
        
    Returns:
        True if the configuration was saved successfully, False otherwise
    """
    config = load_config()
    
    # Handle nested keys with dot notation (e.g., "categories.documentation")
    if "." in key:
        parts = key.split(".")
        parent = config
        for part in parts[:-1]:
            if part not in parent or not isinstance(parent[part], dict):
                parent[part] = {}
            parent = parent[part]
        parent[parts[-1]] = value
    else:
        config[key] = value
    
    return save_config(config)
