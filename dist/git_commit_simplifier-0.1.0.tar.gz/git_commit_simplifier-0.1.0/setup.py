from setuptools import setup, find_packages
import os

# Lire README.md s'il existe, sinon utiliser une description par défaut
readme_path = os.path.join(os.path.dirname(__file__) or '.', 'README.md')
long_description = "A tool to simplify Git commit message creation by analyzing changes"

if os.path.exists(readme_path):
    try:
        with open(readme_path, "r", encoding="utf-8") as fh:
            long_description = fh.read()
    except Exception as e:
        print(f"Warning: Could not read README.md: {e}")

setup(
    name="git-commit-simplifier",
    version="0.1.0",
    author="Christopher Dato",
    author_email="christopherdato08@gmail.com",
    description="A tool to simplify Git commit message creation by analyzing changes",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Chris000888/git-commit-simplifier",
    project_urls={
        "Bug Tracker": "https://github.com/Chris000888/git-commit-simplifier/issues",
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Version Control :: Git",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    python_requires=">=3.7",
    install_requires=[
        "gitpython>=3.1.40",
        "click>=8.1.7",
        "colorama>=0.4.6",
        "prompt_toolkit>=3.0.36",    # Ajout pour une meilleure interface interactive
    ],
    entry_points={
        "console_scripts": [
            "git-commit-simplifier=git_commit_simplifier.cli:main",
        ],
    },
)
