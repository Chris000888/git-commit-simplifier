"""
Git Commit Simplifier - A tool to simplify Git commit message creation
"""

__version__ = "0.1.2"
__author__ = "Christopher Dato"
__email__ = "christopherdato08@gmail.com"
